from food_search import find_food

if __name__ == '__main__':
    print(find_food(['tomatoes','eggs','pasta'], ['plum']))